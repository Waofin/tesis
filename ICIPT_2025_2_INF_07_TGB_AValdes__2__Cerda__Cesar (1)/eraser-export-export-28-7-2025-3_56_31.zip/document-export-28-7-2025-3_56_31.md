# 

```
# Detección de Exoplanetas: Algoritmo Híbrido RSM-PACO

title Detección de Exoplanetas: Algoritmo Híbrido RSM-PACO

# Definir los componentes principales
components:
  # Entrada de datos
  telescopio [icon: telescope, color: blue] {
    label: "Datos de Imagen Directa"
    description: "Telescopio"
  }
  
  # Pre-procesamiento
  preprocessing [icon: settings, color: orange] {
    label: "Pre-procesamiento"
    items: [
      "Calibración",
      "Reducción ruido", 
      "Normalización"
    ]
  }
  
  # Algoritmo RSM
  rsm [icon: cpu, color: orange] {
    label: "RSM"
    subtitle: "Regime Switch Model"
    items: [
      "Detección cambios",
      "Identificación regímenes",
      "Modelado temporal",
      "Filtrado adaptativo"
    ]
  }
  
  # Algoritmo PACO
  paco [icon: chart-line, color: orange] {
    label: "PACO"
    subtitle: "PCA + Covarianza"
    items: [
      "Análisis componentes",
      "Reducción dimensión",
      "Matriz covarianza",
      "Extracción señal"
    ]
  }
  
  # Integración híbrida
  hybrid [icon: puzzle-piece, color: yellow] {
    label: "Integración Híbrida"
    subtitle: "RSM-PACO"
    items: [
      "Fusión algoritmos",
      "Optimización parámetros"
    ]
  }
  
  # Detección de candidatos
  detection [icon: search, color: green] {
    label: "Detección de Candidatos"
    description: "Exoplanetas"
  }
  
  # Validación
  validation [icon: check-circle, color: green] {
    label: "Validación y Caracterización"
    description: "Sí/No Planeta"
  }
  
  # Resultado final
  result [icon: target, color: green] {
    label: "Resultado Final"
    items: [
      "Posición",
      "Magnitud", 
      "Probabilidad"
    ]
  }

# Definir las conexiones/flujo
flow:
  telescopio --> preprocessing: "Datos brutos"
  preprocessing --> rsm: "Datos procesados"
  preprocessing --> paco: "Datos procesados"
  rsm --> hybrid: "Análisis temporal"
  paco --> hybrid: "Análisis espacial"
  hybrid --> detection: "Señal híbrida"
  hybrid --> validation: "Candidatos"
  hybrid --> result: "Análisis final"

# Notas y ventajas
notes:
  ventajas [color: gray] {
    title: "Ventajas del Método Híbrido"
    items: [
      "Mayor precisión en detección",
      "Reducción de falsos positivos", 
      "Mejor manejo de ruido instrumental"
    ]
  }
  
  aplicacion [color: gray] {
    title: "Aplicación"
    items: [
      "Telescopios de imagen directa",
      "Detección de exoplanetas gigantes",
      "Sistemas estelares jóvenes"
    ]
  }
```


